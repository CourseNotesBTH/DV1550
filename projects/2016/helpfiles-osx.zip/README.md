# This is the project for the course DV1552 HT16.

The repo has 3 folders

## LINUX
Have pre-built static library located in Linux/src/libpng. To test simply use the Makefile:
```
    make or make all
```

## OS X
Have pre-built static library located in OSX/src/libpng. To test simply use the Makefile:
```
    make or make all
```

## WINDOWS
Not yet implemented.
