#ifndef STUDENTFUNCTIONS_H
#define STUDENTFUNCTIONS_H

#include "functions.h"

//Your definitions here

#endif
