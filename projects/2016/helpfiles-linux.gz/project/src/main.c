#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "studentFunctions.h"

int main ()
{
    Image plain;
    plain.height = 512;
    plain.width = 1024;

	plain.pixels = (Pixel**) malloc(sizeof(Pixel*) * plain.height);
	for(int i = 0; i < plain.height; i++)
	{
		plain.pixels[i] = (Pixel*) malloc(sizeof(Pixel) * plain.width);
		for(int j = 0; j < plain.width; j++)
		{
			plain.pixels[i][j].r = 255-(i/2);
			plain.pixels[i][j].g = j/4;
			plain.pixels[i][j].b = 0;
		}
	}

    printf("Saving PNG\n");
	writeImage("test.png", &plain);

    for(int i = 0; i < plain.height; i++)
        free(plain.pixels[i]);
    free(plain.pixels);

    return 0;
}
